# Bring on Vera

This is Vera, your chief of staff. She is the only thing you install by hand. Once she is running she
fetches the rest of your team and keeps everything up to date herself.

## Install her

1. Unzip this folder if you have not already. You should have a folder called `vera` containing
   `SKILL.md` and a `reference` folder.
2. Put the whole `vera` folder inside `.claude/skills/` in the folder you work in.
   So you end up with `.claude/skills/vera/SKILL.md`.
   If there is no `.claude/skills` folder yet, create it.
3. Open Claude in that folder and say **Hey Vera**.

She will introduce herself and walk you through the rest, including your GitHub token, your Airtable
base and the other three agents.

## What is in here

- `SKILL.md` is Vera herself.
- `reference/how-we-work.md` is the rulebook she reads at the start of every session. She does not
  work properly without it, so keep it where it is.
- `reference/your-base.template.md` is the map of where your data lives. Vera fills it in with you.

## Two things worth knowing before you start

- **Nothing is ever sent for you.** Every message to a tenant, applicant, contractor or agency is
  prepared and held for you to read, including anything a routine prepares overnight. There is no
  setting that changes that.
- **This is built for landlords in the United States**, and your state's rules come from settings you
  record yourself. City and county rules are a known gap. Vera never tells you what the law is.

Questions during the program go in your cohort channel.
